#define ILI9486_DRIVER   // Enable ILI9486 Driver
#define TFT_PARALLEL_8_BIT  // Enable 8-bit parallel mode

// ESP32 Pin Configuration for TFT Display
#define TFT_CS   33  // Chip Select
#define TFT_DC   15  // Data/Command
#define TFT_RST  32  // Reset
#define TFT_WR   4   // Write Strobe
#define TFT_RD   2   // Read Strobe

// 8-bit parallel data bus
#define TFT_D0   12
#define TFT_D1   13
#define TFT_D2   26
#define TFT_D3   25
#define TFT_D4   17
#define TFT_D5   16
#define TFT_D6   27
#define TFT_D7   14

// Enable fonts and features
#define LOAD_GLCD  
#define LOAD_FONT2  
#define LOAD_FONT4  
#define LOAD_FONT6  
#define LOAD_FONT7  
#define LOAD_FONT8  
#define LOAD_GFXFF  
#define SMOOTH_FONT  

// Set SPI Frequency (not used for parallel)
#define SPI_FREQUENCY  27000000

